# RISC-V Assembly Lab
# E Numbers :
# Names :
# Description: 

.data
# Initialize the array with 5 sample integers
array:  .word 12, 7, 4, 15, 8   
length: .word 5                 

.text
.globl _start

_start:
    la   t0, array      # t0 = base address of the array
    lw   t1, length     # t1 = length of the array (5)
    li   t2, 0          # t2 = loop counter (i = 0)

# ---------------------------------------------------------
# YOUR CODE GOES HERE:
# Write the logic to iterate through the array.
# Check if each element is even or odd using 'andi'.
# Apply the addition or subtraction, and store it back.
# ---------------------------------------------------------

done:
    nop                 # Jump here when the array processing is complete