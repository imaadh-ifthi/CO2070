`timescale 1ns / 1ps

module tb_alu;

    // inputs are reg so we can drive them in the testbench
    reg [7:0] DATA1;
    reg [7:0] DATA2;
    reg [2:0] SELECT;
    wire [7:0] RESULT; // alu output

    // instantiate the alu
    alu uut (
        .DATA1(DATA1),
        .DATA2(DATA2),
        .RESULT(RESULT),
        .SELECT(SELECT)
    );

    initial begin
        // dump for gtkwave
        $dumpfile("alu_waveform.vcd"); 
        $dumpvars(0, tb_alu);          

        // print whenever something changes
        $monitor("Time: %0t | SELECT: %b | DATA1: %d | DATA2: %d | RESULT: %d", 
                 $time, SELECT, DATA1, DATA2, RESULT);

        // start with everything 0
        DATA1 = 8'd0;
        DATA2 = 8'd0;
        SELECT = 3'b000;
        #10;

        // test 1: FORWARD (select 000)
        // should output 25 after 1ns
        DATA1 = 8'd10; 
        DATA2 = 8'd25; 
        SELECT = 3'b000;
        #10; 

        // test 2: ADD (select 001)
        // 10 + 25 = 35, takes 2ns
        DATA1 = 8'd10; 
        DATA2 = 8'd25; 
        SELECT = 3'b001;
        #10;

        // test 3: AND (select 010)
        // 11110000 & 10101010 = 10100000 (160)
        DATA1 = 8'b11110000; 
        DATA2 = 8'b10101010; 
        SELECT = 3'b010;
        #10;

        // test 4: OR (select 011)
        // 11110000 | 00001111 = 11111111 (255)
        DATA1 = 8'b11110000; 
        DATA2 = 8'b00001111; 
        SELECT = 3'b011;
        #10;

        // test 5: reserved select values
        // should just be 0
        DATA1 = 8'd100; 
        DATA2 = 8'd100; 
        SELECT = 3'b100; 
        #5;
        
        SELECT = 3'b111; 
        #10;

        $finish;
    end
endmodule