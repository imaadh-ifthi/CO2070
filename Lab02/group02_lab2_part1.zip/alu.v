`timescale 1ns / 1ps

// forward unit
// just sends data2 to the output, for loadi and mov
// needs a #1 delay
module forward_unit(input [7:0] data2, output reg [7:0] out);
    always @(*) #1 out = data2;
endmodule

// add unit
// adds data1 and data2
// addition takes longer so #2 delay
module add_unit(input [7:0] data1, input [7:0] data2, output reg [7:0] out);
    always @(*) #2 out = data1 + data2;
endmodule

// and unit
// bitwise AND 
module and_unit(input [7:0] data1, input [7:0] data2, output reg [7:0] out);
    always @(*) #1 out = data1 & data2;
endmodule

// or unit
// bitwise OR
module or_unit(input [7:0] data1, input [7:0] data2, output reg [7:0] out);
    always @(*) #1 out = data1 | data2;
endmodule

// top level alu module
// has two 8-bit inputs and a 3-bit select
module alu (DATA1, DATA2, RESULT, SELECT);
    input [7:0] DATA1, DATA2;
    input [2:0] SELECT;
    output reg [7:0] RESULT;

    // wires for the outputs of the functional units
    wire [7:0] fwd_out, add_out, and_out, or_out;

    // instantiate all the units
    // they run in parallel
    forward_unit f1(.data2(DATA2), .out(fwd_out));
    add_unit     a1(.data1(DATA1), .data2(DATA2), .out(add_out));
    and_unit     an1(.data1(DATA1), .data2(DATA2), .out(and_out));
    or_unit      o1(.data1(DATA1), .data2(DATA2), .out(or_out));

    // mux to pick the right result based on the select signal
    always @(*) begin
        case(SELECT)
            3'b000: RESULT = fwd_out;   // forward
            3'b001: RESULT = add_out;   // add
            3'b010: RESULT = and_out;   // and
            3'b011: RESULT = or_out;    // or
            // set to 0 for any unused select combinations
            default: RESULT = 8'b00000000; 
        endcase
    end
endmodule